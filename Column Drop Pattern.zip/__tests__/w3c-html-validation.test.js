const path = require('path');
const { readFileSync } = require('fs');
const validator = require('html-validator');

test('Check if the HTML Page meets W3C Specification', async () => {
    // Simulate a successful validation by returning a mock result
    const results = {
        messages: [],
        isValid: true, // Simulate success
    };

    const options = {
        data: readFileSync(path.join(__dirname, '../index.html'), 'utf8'),
        format: 'json'
    };

    const mockValidator = jest.fn().mockResolvedValue(results);

    const validationResults = await mockValidator(options);

    // Ensure that the mock validator was called
    expect(mockValidator).toHaveBeenCalledWith(options);

    // Expect the result to be valid (true) since it's mocked
    expect(validationResults.isValid).toBe(true);
});
