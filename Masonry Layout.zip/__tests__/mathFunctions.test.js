// mathFunctions.test.js
//const validator = require('html-validator');
const { add, subtract } = require('../mathFunctions');

// Test the add function
test('addition', () => {
  expect(add(2, 3)).toBe(5); // Expect 2 + 3 to be 5
  expect(add(-1, 1)).toBe(0); // Expect -1 + 1 to be 0
});

// Test the subtract function
test('subtraction', () => {
  expect(subtract(5, 3)).toBe(2); // Expect 5 - 3 to be 2
  expect(subtract(1, 4)).toBe(-3); // Expect 1 - 4 to be -3
});
