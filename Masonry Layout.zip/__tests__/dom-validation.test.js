const path = require('path');
const { readFileSync } = require('fs');
const { JSDOM } = require('jsdom');

let document;
beforeAll(() => {
    const htmlFile = readFileSync(path.join(__dirname, '../index.html'), 'utf-8');
    const dom = new JSDOM(htmlFile, { contentType: 'text/html' });
    document = dom.window.document;
    global.dom = dom;
});

test('Should check that embedded style sheets are not used', () => {
    const styleTags = document.querySelectorAll('style');
    expect(styleTags.length).toEqual(0);
});

test('Should check if link tag is used referring to an external file within the project', () => {
    const linkTags = document.querySelectorAll('link[rel="stylesheet"]');
    linkTags.forEach((linkTag) => {
        const hrefValue = linkTag.getAttribute('href');
        expect(hrefValue).not.toMatch(/^http/);
    });
});

test('Should Check class/id values should not have dot/hash', () => {
    const divElements = document.querySelectorAll('div');
    divElements.forEach((div) => {
        const attrValue = div.getAttribute('class');
        expect(attrValue).toBeDefined(); // Check that the attribute exists
        if (attrValue !== null) {
            expect(attrValue).not.toMatch(/[.#]/); // Check that the attribute value doesn't contain dots or hashes
        }
    });
});


test('Should have 5 div elements with class/id attributes', () => {
    const divElements = document.querySelectorAll('div');
    divElements.forEach((div) => {
        const attrValue = div.getAttribute('class');
        expect(attrValue).toBeDefined(); // Check that the attribute exists
        if (attrValue !== null) {
            expect(attrValue).not.toMatch(/[.#]/); // Check that the attribute value doesn't contain dots or hashes
        }
    });

});

test("Blocks inside each column should have two class names for styling width and height", () => {
    const div = document.querySelector('div:nth-child(2)'); // Adjust the selector as needed
    const classValue = div.getAttribute('class');
    const classNames = classValue.split(' ');
    expect(classNames.length).toBe(2); // Check if there are two class names
});