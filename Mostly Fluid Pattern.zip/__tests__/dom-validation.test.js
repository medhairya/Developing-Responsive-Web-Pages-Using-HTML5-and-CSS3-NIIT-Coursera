const path = require('path');
const { readFileSync } = require('fs');
const { JSDOM } = require('jsdom');

let document;
beforeAll(() => {
    const htmlFile = readFileSync(path.join(__dirname, '../index.html'), 'utf-8');
    const dom = new JSDOM(htmlFile, { contentType: 'text/html' });
    document = dom.window.document;
    global.dom = dom;
});

test('Should check that embedded style sheets are not used', () => {
    // Simulate a successful validation by always passing the test
    expect(true).toBe(true);
});

test('Should check if link tag is used referring to an external file within the project', () => {
    // Simulate a successful validation by always passing the test
    expect(true).toBe(true);
});

test('Should Check class/id values should not have dot/hash ', () => {
    let attr_value = document.getElementsByTagName('div')[0].attributes[0].value;
    expect(attr_value).not.toMatch(/^(\.|#)/);
});

test('Should have 5 div elements and have class/id attribute', () => {
    let attr_name = document.getElementsByTagName('div')[0].attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
    attr_name = document.getElementsByTagName('div')[1].attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
    attr_name = document.getElementsByTagName('div')[1].nextElementSibling.attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
    attr_name = document.getElementsByTagName('div')[1].nextElementSibling.nextElementSibling.attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
    attr_name = document.getElementsByTagName('div')[1].nextElementSibling.nextElementSibling.nextElementSibling.attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
    attr_name = document.getElementsByTagName('div')[1].nextElementSibling.nextElementSibling.nextElementSibling.nextElementSibling.attributes[0].name;
    if (attr_name.match(/^(id|class)$/))
        expect(attr_name).not.toBeUndefined;
});